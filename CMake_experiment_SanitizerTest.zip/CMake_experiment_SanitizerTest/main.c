#include <stdlib.h>

void* p;

int main() {
    // memory
    char *x = (char*)malloc(10 * sizeof(char*));
    free(x);

    // leak
    p = malloc(7);
    p = 0; // The memory is leaked here.

    return x[5];
}