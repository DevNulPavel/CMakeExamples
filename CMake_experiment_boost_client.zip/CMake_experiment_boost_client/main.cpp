#define BOOST_EXCEPTION_DISABLE 1
// std
#include <thread>
#include <mutex>
#include <iostream>
#include <string>
#include <unordered_map>
#include <condition_variable>
// Boost
#include <boost/asio.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/make_shared.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/regex.hpp>
#include <boost/bind.hpp>
#include <boost/thread/thread.hpp>
// data
#include "data.pb.h"

// сокращения для пространств имен
namespace ba = boost::asio;
namespace bs = boost::system;

using namespace std;
using namespace ba;
using namespace bs;
using namespace protobuf;

typedef shared_ptr<Data> DataPtr;
typedef vector<DataPtr> DataResults;
typedef shared_ptr<DataResults> DataResultsPtr;

/////////////////////////////////////////////////////////
// std
const int tasksSize = 1; // 150
const int maxActiveThreadsCount = 10;
atomic_int activeThreadsCount;
mutex dataMutexObject;

mutex conditionMutexObject;
unique_lock<mutex> uniqueLock(conditionMutexObject);
condition_variable conditionVariable;
// boost
io_service service;
ip::tcp::endpoint ep( ip::address::from_string("127.0.0.1"), 8001);
/////////////////////////////////////////////////////////


//// Проверка готовности чтения
//size_t read_complete(char* buf, const bs::error_code & err, size_t bytes) {
//    if (err){
//        return 0;
//    }
//    if(bytes == 0){
//        return 1;
//    }
//    if(buf == nullptr){
//        return 1;
//    }
//
//    
//    // производим поиск переноса строки по массиву байтов
//    bool found = std::find(buf, buf + bytes, '\n') < (buf + bytes);
//    // we read one-by-one until we get to enter, no buffering
//    return found ? 0 : 1;
//}

void syncHandleData(DataPtr sourceData, int index, DataResultsPtr results){
    // Сериализация в блок данных
    int dataSize = sourceData->ByteSize();
    std::vector<char> sourceDataVector(dataSize);
    bool serializeSuccess = sourceData->SerializeToArray(sourceDataVector.data(), dataSize);
    if (serializeSuccess == false) {
        assert("Serialize error");
    }
    
    // Создаем сокет
    ip::tcp::socket socket(service);
    
    // Соединяемся
    // И пишем в сокет
    boost::system::error_code connectError;
    socket.connect(ep, connectError);
    
    // Проверка ошибки
    if(connectError.value() != 0){
        // Закрываем сокет
        socket.close();
        std::cout << "Connect error" << endl;
        return;
    }
    
    // И пишем в сокет
    boost::system::error_code writeError;
    socket.write_some(buffer(sourceDataVector.data(), dataSize), writeError);
    
    // чистим отправленные данные
    sourceDataVector.clear();
    
    // Проверка ошибки
    if(writeError.value() != 0){
        // Закрываем сокет
        socket.close();
        std::cout << "Ошибка записи" << endl;
        return;
    }
    
    // Ожидаем готовность данных
    int availableSocketSize = socket.available();
    while (availableSocketSize == 0) {
        // иcкусственная задержка
        std::this_thread::sleep_for(std::chrono::nanoseconds(100));
        availableSocketSize = socket.available();
    }
    
    // создаем буффер и читаем из сокета
    std::vector<char> receivedData(availableSocketSize);
    // Вариант с проверкой завершения
    //int receivedBytes = read(socket, buffer(receivedData), boost::bind(read_complete, receivedData.data(), _1, _2));
    // Вариант с чтением данных
    //int receivedBytes = read(socket, buffer(receivedData));
    // Чтение с помощью readSome
    boost::system::error_code readError;
    int receivedBytes = socket.read_some(buffer(receivedData), readError);
    
    // Проверка ошибки
    if(readError.value() != 0){
        // Закрываем сокет
        socket.close();
        std::cout << "Ошибка чтения" << endl;
        return;
    }
    
    // Закрываем сокет
    if (receivedBytes == 0) {
        socket.close();
        std::cout << "No received bytes" << endl;
        return;
    }
    
    // Закрываем сокет
    socket.close();
    
    // Создаем объект результата
    DataPtr transferResultData = make_shared<protobuf::Data>();
    transferResultData->ParseFromArray(receivedData.data(), receivedBytes);
    
    // Сохранять тут + блокировка
    dataMutexObject.lock();
    (*results)[index] = transferResultData;
    dataMutexObject.unlock();
    
    // оповещаем о возможноти запуска еще одного потока
    activeThreadsCount--;
    conditionVariable.notify_one();
}

int main(int argc, char* argv[]) {
    // Результаты
    DataResultsPtr results = make_shared<DataResults>();
    results->resize(tasksSize);

    // Закидывание задач на обработку на сервер
    boost::thread_group threads;
    for (int i = 0; i < tasksSize; i++) {
        // Сырые байты
        size_t dataSize = 6;
        char rawData[] = {2, 4, 6, 8, 12, 32};
        
        // Подготавливаем ProtoBuf объект
        DataPtr sourceTransferData = make_shared<protobuf::Data>();
        sourceTransferData->set_name("Test name");
        sourceTransferData->set_datasize(dataSize);
        sourceTransferData->set_data(rawData);
        //sourceTransferData->PrintDebugString();

        // Количество активных потоков
        activeThreadsCount++;
        
        // создаем поток выполнения
        threads.create_thread(boost::bind(syncHandleData, sourceTransferData, i, results));
     
        while (activeThreadsCount >= maxActiveThreadsCount) {
            conditionVariable.wait(uniqueLock);
        }
     
//        // Блокировка запуска большого количества потоков
//        while(activeThreadsCount >= maxActiveThreadsCount){
//            boost::this_thread::sleep(boost::posix_time::millisec(100));
//        }
    }
    threads.join_all();
    
    // Вывод результатов
    int i = 0;
    for (const DataPtr& resultData: *results) {
        if (resultData == nullptr) {
            continue;
        }
        std::cout << "Item at: " << i << std::endl;
        i++;
        resultData->PrintDebugString();
        std::cout << std::endl;
    }
}
