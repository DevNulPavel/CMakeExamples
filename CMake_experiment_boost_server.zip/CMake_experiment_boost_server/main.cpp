#define BOOST_EXCEPTION_DISABLE 1
// std
#include <thread>
#include <mutex>
#include <iostream>
#include <string>
#include <unordered_map>
#include <condition_variable>
// Boost
#include <boost/asio.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/make_shared.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/regex.hpp>
#include <boost/bind.hpp>
#include <boost/thread/thread.hpp>
// data
#include "data.pb.h"

// сокращения для пространств имен
namespace ba = boost::asio;
namespace bs = boost::system;

using namespace std;
using namespace ba;
using namespace bs;
using namespace protobuf;

typedef shared_ptr<Data> DataPtr;
typedef vector<DataPtr> DataResults;
typedef shared_ptr<DataResults> DataResultsPtr;


/////////////////////////////////////////////////////////
io_service service;
/////////////////////////////////////////////////////////

size_t read_complete(char* buff, const bs::error_code & err, size_t bytes) {
    if (err){
        return 0;
    }
//    if(bytes == 0){
//        return 1;
//    }
//    if(buff == nullptr){
//        return 1;
//    }
    
    // производим поиск переноса строки по массиву байтов
    bool found = std::find(buff, buff + bytes, '\n') < (buff + bytes);
    
    // we read one-by-one until we get to enter, no buffering
    return found ? 0 : 1;
}

void handle_connections() {
    // протокол и порт
    ip::tcp::acceptor acceptor(service, ip::tcp::endpoint(ip::address::from_string("127.0.0.1"), 8001));
    
    while(true){
        // Сокет, который будет принимать подключения
        ip::tcp::socket socket(service);
        
        // ожидаем подключения
        boost::system::error_code acceptError;
        acceptor.accept(socket, acceptError);
        
        // Проверка ошибки
        if(acceptError.value() != 0){
            socket.close();
            std::cout << "Accept error" << endl;
            continue;
        }
        
        int availableSocketSize = socket.available();
        while (availableSocketSize == 0) {
            // иcкусственная задержка
            std::this_thread::sleep_for(std::chrono::nanoseconds(100));
            availableSocketSize = socket.available();
        }
        
        if (availableSocketSize > 0) {
            // Буффер данных
            std::vector<char> receivedData;
            receivedData.resize(availableSocketSize);
        
            // Производим чтение того, что отправили серверу
            // Вариант с проверкой завершения
            // int receivedBytes = read(socket, buffer(receivedData), boost::bind(read_complete, receivedData.data(), _1, _2));
            // Вариант с чтением данных
            //int receivedBytes = read(socket, buffer(receivedData));
            // Чтение с помощью readSome
            boost::system::error_code readError;
            int receivedBytes = socket.read_some(buffer(receivedData), readError);
        
            // Проверка ошибки
            if(readError.value() != 0){
                // Закрываем сокет
                socket.close();
                std::cout << "Ошибка чтения" << endl;
                return;
            }
        
            // Создаем объект данных
            DataPtr transferResultData = make_shared<protobuf::Data>();
            transferResultData->ParseFromArray(receivedData.data(), receivedBytes);
            
            // Модифицируем полученные данные
            string newName = "Server answer:" + transferResultData->name();
            size_t rawDataSize = 10;
            char rawData[] = {2, 4, 6, 8, 12, 32, 12, 5, 5, 2};
            
            // иcкусственная задержка
            std::this_thread::sleep_for(std::chrono::milliseconds(200));
            
            // Обновляем данные
            transferResultData->set_name(newName);
            transferResultData->set_datasize(rawDataSize);
            transferResultData->set_data(rawData);
            
            // Сериализация в блок данных
            int dataSize = transferResultData->ByteSize();
            std::vector<char> sourceDataVector(dataSize);
            bool serializeSuccess = transferResultData->SerializeToArray(sourceDataVector.data(), dataSize);
            if (serializeSuccess == false) {
                assert("Serialize error");
            }
            
            // пишем в сокет
            boost::system::error_code writeError;
            socket.write_some(buffer(sourceDataVector.data(), dataSize), writeError);
            
            // Проверка ошибки
            if(writeError.value() != 0){
                // Закрываем сокет
                socket.close();
                std::cout << "Ошибка записи" << endl;
                return;
            }
        }
        
        // закрываем сокет
        socket.close();
    }
}

int main(int argc, char* argv[]) {
    handle_connections();
    return 0;
}