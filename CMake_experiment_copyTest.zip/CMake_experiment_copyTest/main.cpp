

#include <vector>
#include <iostream>

std::vector<int> test(int num){
	std::vector<int> result;
	result.push_back(5);
	size_t adress = (size_t)(&result);
	std::cout << "Inside" << num << ": " << adress << "\n";
	return result;
}

std::vector<int> getData1() {
	std::vector<int> result;
    const int n = 10000;
    result.resize(n);
    for (int i = 0; i < n; ++i) {
        result[i] = i;
    }
    return result;
}

void getData2(std::vector<int> &res) {
    const int n = 10000;
    res.resize(n);
    for (int i = 0; i < n; ++i) {
        res[i] = i;
    }
}

int main (int argc, char** argv) {
	size_t adress = 0;

	std::cout << "!!!!!!!! Adress test !!!!!!!!\n";

	std::vector<int> result1 = test(1);
	adress = (size_t)(&result1);
	std::cout << "Outside1: " << adress << "\n\n";


	std::vector<int> result2;
	adress = (size_t)(&result2);
	std::cout << "Outside2 before: " << adress << "\n";

	result2 = test(2);
	
	adress = (size_t)(&result2);
	std::cout << "Outside2 after: " << adress << "\n\n\n";
	

	std::cout << "!!!!!!!! Time test !!!!!!!!\n";

	std::chrono::time_point<std::chrono::system_clock> start, end;
	int elapsedMilisec = 0;

	start = std::chrono::system_clock::now();
    for (int i = 0; i < 50000; ++i) {
        std::vector<int> a = getData1();
    }
    end = std::chrono::system_clock::now();
    elapsedMilisec = std::chrono::duration_cast<std::chrono::milliseconds>
                         (end-start).count();
    std::cout << "Return variant: " << elapsedMilisec << "msec\n";

    start = std::chrono::system_clock::now();
    for (int i = 0; i < 50000; ++i) {
        std::vector<int> a;
        getData2(a);
    }
    end = std::chrono::system_clock::now();
    elapsedMilisec = std::chrono::duration_cast<std::chrono::milliseconds>
                         (end-start).count();
    std::cout << "Link variant: " << elapsedMilisec << "msec\n";

	return 0;
}


