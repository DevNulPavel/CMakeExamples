

#include <vector>
#include <iostream>

int main (int argc, char** argv) {
	int a[] = {1, 2, 3};
	printf("%zu\n", size_t(&a));
    return 0;
}
