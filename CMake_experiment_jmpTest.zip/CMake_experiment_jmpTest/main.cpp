#include <iostream>
#include <csetjmp>

std::jmp_buf jump_buffer;
std::jmp_buf main_buffer;
std::jmp_buf load_buffer;
bool loadingStarted = false;


class TestClass{
public:
    TestClass(){
        std::cout << "Create test class\n";
    }
    
    ~TestClass(){
        std::cout << "DELETE test class\n";
    }
};

//[[noreturn]] void a(int count)
void a(int count) {
    // информация, что мы зашли сюда
    std::cout << "a(" << count << ") вызван\n";
    
    TestClass testObject;
    
    // переходим снова на "if (setjmp(jump_buffer) != 5)" >>>> setjmp() возвратит jumpIfValue
    int jumpIfValue = count+1;
    std::longjmp(jump_buffer, jumpIfValue);
}


void testLoading(){
    // какая-то загрузка
    std::cout << "loading 0\n";
    
    if(setjmp(load_buffer) == 0){
        std::longjmp(main_buffer, 1);
    }
    
    TestClass testObject1;
    
    // какая-то загрузка
    std::cout << "loading 1\n";
    
    if(setjmp(load_buffer) == 0){
        std::longjmp(main_buffer, 1);
    }
    
    TestClass testObject2;
    
    // какая-то загрузка
    std::cout << "loading 2\n";
}

void mainLoop(){
    if (setjmp(main_buffer) == 0){
        std::cout << "Test\n";
        
        if (loadingStarted) {
            std::longjmp(load_buffer, 1);
        }else{
            loadingStarted = true;
            testLoading();
        }
    }
    
    std::cout << "Main loop end\n";
}

int main() {
    volatile int count = 0; // Изменяемая локальная переменная в блоке setjmp должна быть volatile
    // Сюда будет осуществлен переход после очередной операции longjmp - Оператор равенства с константным выражением в if
    if (setjmp(jump_buffer) != 5) {
        a(count++);  // Это приведёт к выходу из setjmp()
    }
    
    std::cout << "\n\n\n";
    
    for (int i = 0; i < 3; i++) {
        mainLoop();
    }
}