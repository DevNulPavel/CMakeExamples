

#include <vector>
#include <list>
#include <iostream>

int main (int argc, char** argv) {
	std::cout << "!!!!!!!! Time test !!!!!!!!\n";

    size_t sizeValue = 5000000;

	std::chrono::time_point<std::chrono::system_clock> start, end;
	int elapsedMilisec = 0;

    // resize
	start = std::chrono::system_clock::now();
    std::vector<int> test1;
    test1.resize(sizeValue);
    for (int i = 0; i < sizeValue; ++i) {
        test1[0] = 1;
    }
    end = std::chrono::system_clock::now();
    elapsedMilisec = std::chrono::duration_cast<std::chrono::milliseconds>
                         (end-start).count();
    std::cout << "VECTOR RESIZE variant: " << elapsedMilisec << "msec\n";

    // push
    start = std::chrono::system_clock::now();
    std::vector<int> test2;
    for (int i = 0; i < sizeValue; ++i) {
        test2.push_back(1);
    }
    end = std::chrono::system_clock::now();
    elapsedMilisec = std::chrono::duration_cast<std::chrono::milliseconds>
    (end-start).count();
    std::cout << "VECTOR PUSH test variant: " << elapsedMilisec << "msec\n";
    
    // LIST
    start = std::chrono::system_clock::now();
    std::list<int> test3;
    test3.resize(sizeValue);
    for (int i = 0; i < sizeValue; ++i) {
        test3.push_back(1);
    }
    end = std::chrono::system_clock::now();
    elapsedMilisec = std::chrono::duration_cast<std::chrono::milliseconds>
    (end-start).count();
    std::cout << "LIST PUSH variant: " << elapsedMilisec << "msec\n";

	return 0;
}


